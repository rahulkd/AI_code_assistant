# AI Code Assistant - Frontend

React 18 frontend for the AI Code Assistant application with modern UI components and real-time streaming.

## Features

- **Modern React Architecture**: Built with React 18 and Vite
- **Real-time Streaming**: Server-Sent Events integration
- **Syntax Highlighting**: Prism.js for code highlighting
- **Responsive Design**: Mobile-first approach
- **Session Management**: Local storage integration
- **Auto-resizing Components**: Dynamic textarea and containers

## Tech Stack

- **React 18**: Modern React with hooks
- **Vite**: Fast build tool and dev server
- **Prism.js**: Syntax highlighting
- **CSS Variables**: Modern styling approach
- **Fetch Event Source**: SSE client library

## Setup

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start development server**:
   ```bash
   npm run dev
   ```

3. **Build for production**:
   ```bash
   npm run build
   ```

## Component Architecture

### Core Components

- **App.jsx**: Main application component with state management
- **ChatArea.jsx**: Chat interface with message handling
- **SessionsSidebar.jsx**: Session management sidebar
- **Message.jsx**: Individual message rendering with code highlighting

### Custom Hooks

- **useChatStream.js**: Handles SSE streaming and API communication
- **useLocalStorage.js**: Persistent state management

## Styling

The application uses CSS variables for consistent theming:

```css
:root {
  --primary-color: #2563eb;
  --background-color: #ffffff;
  --surface-color: #f8fafc;
  --border-color: #e2e8f0;
  --text-color: #1e293b;
}
```

## Configuration

### Environment Variables

Create a `.env` file in the frontend directory:

```
VITE_API_URL=http://localhost:8000
```

### Vite Configuration

The `vite.config.js` includes:
- React plugin
- API proxy for development
- Build optimizations

## Development

### Adding New Components

1. Create component in `src/components/`
2. Follow the existing naming convention
3. Add proper PropTypes if needed
4. Export from the component file

### Adding New Hooks

1. Create hook in `src/hooks/`
2. Follow the `use` prefix convention
3. Include proper error handling
4. Add JSDoc comments

### Styling Guidelines

- Use CSS variables for consistency
- Follow BEM methodology for class names
- Keep components responsive
- Use modern CSS features (Grid, Flexbox)

## Available Scripts

- `npm run dev`: Start development server
- `npm run build`: Build for production
- `npm run preview`: Preview production build

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Performance Optimizations

- Lazy loading for components
- Efficient re-renders with React.memo
- Optimized bundle size with Vite
- CSS code splitting

## Troubleshooting

### Common Development Issues

**Hot Reload Not Working**
- Restart the dev server
- Check for syntax errors in components

**Styles Not Applying**
- Ensure CSS is imported in components
- Check CSS specificity

**API Calls Failing**
- Verify backend is running
- Check network tab for request details
- Ensure CORS is configured correctly

### Production Issues

**Build Errors**
- Check for TypeScript errors
- Verify all imports are correct
- Ensure environment variables are set

**Performance Issues**
- Use React DevTools Profiler
- Check for unnecessary re-renders
- Optimize large component trees
