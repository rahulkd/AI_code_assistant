import React, { useEffect } from 'react';
import Prism from 'prismjs';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-java';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-bash';
import 'prismjs/components/prism-sql';

function Message({ message, isUser }) {
  useEffect(() => {
    Prism.highlightAll();
  }, [message.content]);

  const formatMessage = (content) => {
    // Split content by code blocks
    const parts = content.split(/(```[\s\S]*?```)/);

    return parts.map((part, index) => {
      if (part.startsWith('```')) {
        // Extract language and code
        const lines = part.split('\n');
        const langLine = lines[0];
        const language = langLine.replace('```', '').trim() || 'javascript';
        const code = lines.slice(1, -1).join('\n');

        return (
          <div key={index} className="code-block">
            <div className="code-header">
              <span className="code-language">{language}</span>
              <button 
                className="copy-button"
                onClick={() => navigator.clipboard.writeText(code)}
                title="Copy code"
              >
                Copy
              </button>
            </div>
            <pre className={`language-${language}`}>
              <code className={`language-${language}`}>{code}</code>
            </pre>
          </div>
        );
      } else {
        // Regular text with basic markdown formatting
        return (
          <div key={index} className="text-content">
            {part.split('\n').map((line, lineIndex) => (
              <div key={lineIndex}>
                {line.split(/\*\*(.*?)\*\*/g).map((text, textIndex) => 
                  textIndex % 2 === 0 ? text : <strong key={textIndex}>{text}</strong>
                )}
              </div>
            ))}
          </div>
        );
      }
    });
  };

  return (
    <div className={`message ${isUser ? 'user-message' : 'assistant-message'}`}>
      <div className="message-content">
        {formatMessage(message.content)}
      </div>
      <div className="message-timestamp">
        {new Date(message.timestamp).toLocaleTimeString()}
      </div>
    </div>
  );
}

export default Message;