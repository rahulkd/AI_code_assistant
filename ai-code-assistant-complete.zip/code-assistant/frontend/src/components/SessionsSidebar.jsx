import React from 'react';

function SessionsSidebar({ sessions, currentSessionId, onSessionSelect, onNewSession }) {
  return (
    <div className="sessions-sidebar">
      <div className="sidebar-header">
        <h3>Sessions</h3>
        <button className="new-session-btn" onClick={onNewSession}>
          New Session
        </button>
      </div>

      <div className="sessions-list">
        {sessions.map((session) => (
          <div
            key={session.id}
            className={`session-item ${currentSessionId === session.id ? 'active' : ''}`}
            onClick={() => onSessionSelect(session.id)}
          >
            <div className="session-title">{session.title}</div>
            <div className="session-date">
              {new Date(session.createdAt).toLocaleDateString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default SessionsSidebar;