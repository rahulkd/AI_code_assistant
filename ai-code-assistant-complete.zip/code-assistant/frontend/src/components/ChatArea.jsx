import React, { useState, useRef, useEffect } from 'react';
import TextareaAutosize from 'react-textarea-autosize';
import Message from './Message';
import { useChatStream } from '../hooks/useChatStream';

function ChatArea({ 
  currentSession, 
  selectedModel, 
  models, 
  onModelChange, 
  onUpdateSession 
}) {
  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef(null);
  const { streamResponse, isStreaming, error } = useChatStream();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentSession?.messages]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!inputMessage.trim() || isStreaming) return;

    const userMessage = {
      role: 'user',
      content: inputMessage.trim(),
      timestamp: new Date().toISOString()
    };

    // Add user message immediately
    const updatedMessages = [...(currentSession?.messages || []), userMessage];
    onUpdateSession(currentSession.id, updatedMessages);

    // Clear input
    setInputMessage('');

    // Add placeholder for assistant response
    const assistantMessage = {
      role: 'assistant',
      content: '',
      timestamp: new Date().toISOString()
    };

    const messagesWithPlaceholder = [...updatedMessages, assistantMessage];
    onUpdateSession(currentSession.id, messagesWithPlaceholder);

    // Stream the response
    await streamResponse(
      currentSession.id,
      selectedModel,
      userMessage.content,
      (chunk) => {
        // Update the last message with the streaming content
        const messages = [...updatedMessages];
        messages[messages.length] = {
          ...assistantMessage,
          content: chunk
        };
        onUpdateSession(currentSession.id, messages);
      },
      (finalContent) => {
        // Update with final content
        const messages = [...updatedMessages];
        messages[messages.length] = {
          ...assistantMessage,
          content: finalContent
        };
        onUpdateSession(currentSession.id, messages);
      }
    );
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="chat-area">
      <div className="chat-header">
        <h2>AI Code Assistant</h2>
        <div className="model-selector">
          <label htmlFor="model-select">Model:</label>
          <select
            id="model-select"
            value={selectedModel}
            onChange={(e) => onModelChange(e.target.value)}
          >
            {models.map((model) => (
              <option key={model.id} value={model.id}>
                {model.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="messages-container">
        {currentSession?.messages?.map((message, index) => (
          <Message
            key={index}
            message={message}
            isUser={message.role === 'user'}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {error && (
        <div className="error-message">
          Error: {error}
        </div>
      )}

      <form className="input-form" onSubmit={handleSubmit}>
        <div className="input-container">
          <TextareaAutosize
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message here..."
            minRows={1}
            maxRows={8}
            className="message-input"
            disabled={isStreaming}
          />
          <button
            type="submit"
            className="send-button"
            disabled={!inputMessage.trim() || isStreaming}
          >
            {isStreaming ? 'Sending...' : 'Send'}
          </button>
        </div>
      </form>
    </div>
  );
}

export default ChatArea;