import { useState, useCallback } from 'react';
import { fetchEventSource } from '@microsoft/fetch-event-source';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

export function useChatStream() {
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState(null);

  const streamResponse = useCallback(async (sessionId, model, message, onChunk, onComplete) => {
    setIsStreaming(true);
    setError(null);

    try {
      let fullResponse = '';

      await fetchEventSource(`${API_URL}/api/chat/stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          session_id: sessionId,
          model: model,
          message: message,
        }),
        onmessage(event) {
          try {
            const data = JSON.parse(event.data);

            if (data.type === 'start') {
              // Stream started
              fullResponse = '';
            } else if (data.type === 'chunk') {
              fullResponse += data.content;
              onChunk(fullResponse);
            } else if (data.type === 'complete') {
              // Stream completed
              onComplete(fullResponse);
            }
          } catch (parseError) {
            console.error('Error parsing SSE data:', parseError);
          }
        },
        onerror(error) {
          console.error('SSE error:', error);
          setError('Connection error occurred');
          setIsStreaming(false);
        },
        onclose() {
          setIsStreaming(false);
        }
      });
    } catch (error) {
      console.error('Stream error:', error);
      setError(error.message);
      setIsStreaming(false);
    }
  }, []);

  return {
    streamResponse,
    isStreaming,
    error
  };
}