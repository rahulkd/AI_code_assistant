import React, { useState, useEffect } from 'react';
import SessionsSidebar from './components/SessionsSidebar';
import ChatArea from './components/ChatArea';
import { useLocalStorage } from './hooks/useLocalStorage';
import './App.css';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

// Simple UUID generator
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function App() {
  const [sessions, setSessions] = useLocalStorage('codeassistant-sessions', []);
  const [currentSessionId, setCurrentSessionId] = useState(null);
  const [selectedModel, setSelectedModel] = useState('ollama-llama2');
  const [models, setModels] = useState([]);

  // Load models on component mount
  useEffect(() => {
    fetchModels();
  }, []);

  // Set initial session
  useEffect(() => {
    if (sessions.length > 0 && !currentSessionId) {
      setCurrentSessionId(sessions[0].id);
    }
  }, [sessions, currentSessionId]);

  const fetchModels = async () => {
    try {
      const response = await fetch(`${API_URL}/api/models`);
      const modelsData = await response.json();
      setModels(modelsData);
      if (modelsData.length > 0) {
        setSelectedModel(modelsData[0].id);
      }
    } catch (error) {
      console.error('Error fetching models:', error);
      // Fallback models if API is not available
      setModels([
        { id: 'ollama-llama2', name: 'Ollama Llama 2', description: 'Local Llama 2 model' },
        { id: 'gpt-4', name: 'GPT-4', description: 'OpenAI GPT-4 model' }
      ]);
    }
  };

  const createNewSession = () => {
    const newSession = {
      id: generateUUID(),
      title: `Session ${sessions.length + 1}`,
      createdAt: new Date().toISOString(),
      messages: []
    };

    setSessions([newSession, ...sessions]);
    setCurrentSessionId(newSession.id);
  };

  const updateSession = (sessionId, messages) => {
    setSessions(prevSessions => 
      prevSessions.map(session => 
        session.id === sessionId 
          ? { 
              ...session, 
              messages,
              title: messages.length > 0 ? messages[0].content.substring(0, 50) + '...' : session.title
            }
          : session
      )
    );
  };

  const selectSession = (sessionId) => {
    setCurrentSessionId(sessionId);
  };

  const getCurrentSession = () => {
    return sessions.find(session => session.id === currentSessionId);
  };

  return (
    <div className="app">
      <SessionsSidebar
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSessionSelect={selectSession}
        onNewSession={createNewSession}
      />

      <ChatArea
        currentSession={getCurrentSession()}
        selectedModel={selectedModel}
        models={models}
        onModelChange={setSelectedModel}
        onUpdateSession={updateSession}
      />
    </div>
  );
}

export default App;