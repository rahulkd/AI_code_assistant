# AI Code Assistant - Backend

FastAPI backend for the AI Code Assistant application.

## Features

- **Streaming Chat API**: Real-time streaming responses using Server-Sent Events
- **Model Selection**: Support for multiple AI models (Ollama, OpenAI, Claude)
- **Session Management**: Persistent conversation sessions
- **CORS Support**: Configured for frontend integration
- **Health Monitoring**: Health check endpoints

## Setup

1. **Create virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the server**:
   ```bash
   uvicorn main:app --reload --port 8000
   ```

4. **Access API documentation**:
   Open http://localhost:8000/docs in your browser

## API Endpoints

- `POST /api/chat/stream` - Streaming chat endpoint
- `GET /api/models` - Get available AI models
- `GET /api/sessions/{session_id}` - Get session history
- `GET /api/health` - Health check

## Integration with Local Models

To integrate with Ollama or other local models, modify the `simulate_ai_response` function in `main.py`:

```python
async def simulate_ai_response(message: str, model: str) -> str:
    if model.startswith("ollama-"):
        # Your Ollama integration code here
        pass
    # ... rest of the function
```

## Environment Variables

- `HOST`: Server host (default: 0.0.0.0)
- `PORT`: Server port (default: 8000)
- `CORS_ORIGINS`: Allowed CORS origins

## Production Deployment

For production, use a production WSGI server:

```bash
pip install gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker
```
