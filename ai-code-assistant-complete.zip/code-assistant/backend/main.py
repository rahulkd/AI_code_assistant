from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict
import json
import asyncio
import uuid
from datetime import datetime
import uvicorn

app = FastAPI(title="AI Code Assistant API")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models
class ChatMessage(BaseModel):
    session_id: str
    model: str
    message: str

class ModelInfo(BaseModel):
    id: str
    name: str
    description: str

# In-memory storage for sessions
sessions_store: Dict[str, List[Dict]] = {}

# Available models
AVAILABLE_MODELS = [
    ModelInfo(id="ollama-llama2", name="Ollama Llama 2", description="Local Llama 2 model"),
    ModelInfo(id="ollama-codellama", name="Ollama CodeLlama", description="Local CodeLlama model"),
    ModelInfo(id="gpt-4", name="GPT-4", description="OpenAI GPT-4 model"),
    ModelInfo(id="claude-3", name="Claude 3", description="Anthropic Claude 3 model")
]

async def simulate_ai_response(message: str, model: str) -> str:
    """Simulate AI response with code detection"""

    # Check if the message is asking for code
    code_keywords = ["code", "function", "class", "script", "program", "algorithm", "implement"]
    is_code_request = any(keyword in message.lower() for keyword in code_keywords)

    if is_code_request:
        if "python" in message.lower():
            return """Here's a Python example for your request:

```python
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Example usage
for i in range(10):
    print(f"F({i}) = {fibonacci(i)}")
```

This recursive implementation generates Fibonacci numbers. For better performance with large numbers, consider using dynamic programming or memoization."""

        elif "javascript" in message.lower() or "react" in message.lower():
            return """Here's a React component example:

```javascript
import React, { useState, useEffect } from 'react';

function Counter() {
    const [count, setCount] = useState(0);

    useEffect(() => {
        document.title = `Count: ${count}`;
    }, [count]);

    return (
        <div>
            <p>You clicked {count} times</p>
            <button onClick={() => setCount(count + 1)}>
                Click me
            </button>
        </div>
    );
}

export default Counter;
```

This component demonstrates state management and side effects in React."""
        else:
            return """Here's a general code example:

```bash
# Install dependencies
npm install express cors

# Start the server
node server.js
```

```javascript
const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});
```

This creates a basic Express.js server with CORS enabled."""

    else:
        # Regular text response
        responses = [
            f"I understand you're asking about: {message}",
            "\n\nThis is a comprehensive topic that involves several key concepts:",
            "\n\n1. **Understanding the Problem**: First, we need to analyze what you're trying to achieve.",
            "\n\n2. **Available Solutions**: There are multiple approaches we can take depending on your specific requirements.",
            "\n\n3. **Best Practices**: I recommend following industry standards and proven patterns.",
            "\n\n4. **Implementation**: Once we have a clear plan, we can proceed with the implementation.",
            "\n\nWould you like me to elaborate on any of these points or provide specific code examples?"
        ]
        return "".join(responses)

@app.get("/api/models", response_model=List[ModelInfo])
async def get_models():
    """Get available AI models"""
    return AVAILABLE_MODELS

@app.post("/api/chat/stream")
async def chat_stream(chat_request: ChatMessage):
    """Handle chat requests with streaming response"""

    try:
        # Generate AI response
        ai_response = await simulate_ai_response(chat_request.message, chat_request.model)

        # Store session message
        if chat_request.session_id not in sessions_store:
            sessions_store[chat_request.session_id] = []

        sessions_store[chat_request.session_id].append({
            "role": "user",
            "content": chat_request.message,
            "timestamp": datetime.now().isoformat()
        })

        async def generate_stream():
            # Send initial response
            yield f"data: {json.dumps({'type': 'start', 'session_id': chat_request.session_id})}\n\n"

            # Stream the response word by word
            words = ai_response.split()
            response_content = ""

            for i, word in enumerate(words):
                response_content += word + " "

                chunk_data = {
                    "type": "chunk",
                    "content": word + " ",
                    "full_content": response_content.strip()
                }

                yield f"data: {json.dumps(chunk_data)}\n\n"

                # Add small delay for streaming effect
                await asyncio.sleep(0.05)

            # Store assistant response
            sessions_store[chat_request.session_id].append({
                "role": "assistant",
                "content": response_content.strip(),
                "timestamp": datetime.now().isoformat()
            })

            # Send completion signal
            yield f"data: {json.dumps({'type': 'complete', 'session_id': chat_request.session_id})}\n\n"

        return StreamingResponse(
            generate_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Access-Control-Allow-Origin": "*",
            }
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/sessions/{session_id}")
async def get_session(session_id: str):
    """Get session history"""
    if session_id in sessions_store:
        return {"session_id": session_id, "messages": sessions_store[session_id]}
    return {"session_id": session_id, "messages": []}

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
